//======= Copyright (c) Valve Corporation, All rights reserved. ===============
//removed and added to the SteamVR_Settings asset so it can be configured per project