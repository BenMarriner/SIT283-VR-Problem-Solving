﻿//======= Copyright (c) Valve Corporation, All rights reserved. ===============


namespace Valve.VR
{
    public enum SteamVR_Input_ActionScopes
    {
        ActionSet,
        Application,
        Global,
    }
}